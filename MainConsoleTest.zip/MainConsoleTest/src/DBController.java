import java.sql.*;

public class DBController {
	private PreparedStatement ps = null;
	private String sql = null;
	private Connection connection;
	private Statement stmt;
	
    public void dbaseConnect(String url, String user, String pass) throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, user, pass);
    }
    
    public void newData(Integer id,String name,String category,String brand,Integer price,Integer quantity) throws Exception {
    	sql = "Insert into products values (?, ?, ?, ?, ?, ?);";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.setString(2, name);
    	ps.setString(3, category);
    	ps.setString(4, brand);
    	ps.setInt(5, price);
    	ps.setInt(6, quantity);
    	ps.executeUpdate();
    	System.out.println("Succesfully added to database");
    }

    public ResultSet verifyID(Integer ID) throws Exception {
    	sql = "Select productID from products where productID = ?;";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, ID);
    	return ps.executeQuery();
    }
    
    public ResultSet checkOrderStatus(Integer ID) throws Exception{
    	sql = "Select orderStatus from orders where orderID = ?";
    	ps=connection.prepareStatement(sql);
    	ps.setInt(1, ID);
    	return ps.executeQuery();
    }

    public ResultSet getAllProduct() throws Exception {
    	stmt = connection.createStatement();
    	sql = "Select * from products;";
    	return stmt.executeQuery(sql);
    }
    
    public void deleteProduct(Integer id) throws Exception{
    	sql = "delete FROM products where productID = ?;";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.executeUpdate();
    	System.out.println("Product deleted.");
    }
    
    public void newOrder(Integer ID,Integer quantity,String type,String status,Integer cID,Integer pID, Integer caID)throws Exception{
    	sql = "Insert into orders values(?, ? , ?, ?, ?, ?, ?)";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, ID);
    	ps.setInt(2, quantity);
    	ps.setString(3, type);
    	ps.setString(4, status);
    	ps.setInt(5, cID);
    	ps.setInt(6, pID);
    	ps.setInt(7, caID);
    	ps.executeUpdate();
    	System.out.println("New Order has been added");
    }
    
    public void updateProductQty(Integer ID,Integer quantity) throws Exception {
    	sql = "Update store.products SET productQty = ? where productID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, quantity);
    	ps.setInt(2, ID);
    	ps.executeUpdate();
    	System.out.println("Product quantity has been updated.");
    }
    
    public void updateOrderStatus(String status,Integer id) throws Exception{
    	sql = "Update store.orders SET orderStatus = ? where orderID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setString(1, status);
    	ps.setInt(2, id);
    	ps.executeUpdate();
    	System.out.println("Order status has been updated.");
    }
    
    public void deleteOrder(Integer id) throws Exception{
    	sql = "Delete from orders where orderID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.executeUpdate();
    	System.out.println("Order has been deleted.");
    }
    
    public void newCustomer(Integer id, String name,String address,Integer contact) throws Exception{
    	sql = "Insert into customers values(?,?,?,?)";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.setString(2, name);
    	ps.setString(3, address);
    	ps.setInt(4, contact);
    	ps.executeUpdate();
    	System.out.println("New customer has been added.");
    }
    
    public ResultSet getCustomerContact(Integer id) throws Exception{
    	sql = "Select contactNo from customers where customerID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	return ps.executeQuery();
    }
    
    public void updateCustomerAddress(Integer ID, String address) throws Exception {
    	sql = "Update customers SET address = ? where customerID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setString(1, address);
    	ps.setInt(2, ID);
    	ps.executeUpdate();
    	System.out.println("Customer address has been updated.");
    }
    
    public void deleteCustomer(Integer id) throws Exception{
    	sql = "Delete from customers where customerID = ? ";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.executeUpdate();
    	System.out.println("Customer has been deleted");
    }
    
    public void newCashier(Integer id , String name) throws Exception{
    	sql = "Insert into cashier values(?,?)";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.setString(2, name);
    	ps.executeUpdate();
    	System.out.println("New cashier has been added.");
    }
    
    public ResultSet getCashierInfo(Integer id) throws Exception{
    	sql = "select * from cashier where cashierid = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	return ps.executeQuery();
    }
    
    public void deleteCashier(Integer id) throws Exception{
    	sql = "Delete from cashier where cashierID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	ps.executeUpdate();
    	System.out.println("Cashier removed.");
    }
    
    public ResultSet getProductInfo(Integer id)throws Exception {
    	sql = "Select * from products where productID = ?";
    	ps = connection.prepareStatement(sql);
    	ps.setInt(1, id);
    	return ps.executeQuery();
    }

}




