import java.sql.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainConsole {
	private static Scanner scan = new Scanner(System.in);
	private static DBController control;
	
	public static void main(String[] args) {
		control = new DBController();
		//Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/store?useSSL=false","root", null);
		try {
			control.dbaseConnect("jdbc:mysql://localhost:3306/store?useSSL=false","root",null);
			//ps = connect.prepareStatement("Insert into dongerino.personinfo values (?, ?)");
			tableMenu();
		}catch(Exception exc){
			exc.printStackTrace();
		}
	}	
	
	public static void tableMenu() {
		int choice = 0;
		System.out.println("                       ");
		System.out.println("-------Table MENU-------");
		System.out.println("Choose table to be edited: ");
		System.out.println("| 1.  Product Table");
		System.out.println("| 2.  Order Table");
		System.out.println("| 3.  Customer Table");
		System.out.println("| 4.  Cashier Table");
		System.out.println("| 5.  Exit");
		while(choice != 5) {
		System.out.println("Input your choice: ");
		choice = scan.nextInt();
		choices(choice);
		}
	}
	
	public static void productMenu() {
		System.out.println("-------PRODUCTS MENU-------");
		System.out.println("| 0.  Go back to table menu");
		System.out.println("| 1.  Enter new product");
		System.out.println("| 2.  Check product ID");
		System.out.println("| 3.  Show All Products");
		System.out.println("| 4.  Update product quantity");
		System.out.println("| 5.  Delete a product");
	}
	
	public static void orderMenu() {
		System.out.println("--------ORDER MENU---------");
		System.out.println("| 0.  Go back to table menu");
		System.out.println("| 6.  Create a new order");
		System.out.println("| 7.  Check order status");
		System.out.println("| 8.  Update order status");
		System.out.println("| 9.  Delete a order");
	}
	
	public static void customerMenu() {
		System.out.println("--------CUSTOMER MENU------");
		System.out.println("| 0.  Go back to table menu");
		System.out.println("| 10. Add a new customer");
		System.out.println("| 11. Show customer contact no");
		System.out.println("| 12. Update customer address");
		System.out.println("| 13. Delete a customer");
	}
	
	public static void cashierMenu() {
		System.out.println("---------CASHIER MENU------");
		System.out.println("| 0.  Go back to table menu");
		System.out.println("| 14. Add a new cashier");
		System.out.println("| 15. Show a cashier info");
		System.out.println("| 16. Remove a cashier");
	}
	
	public static void choiceExecute(int choice) {
		try {
		switch (choice) {
			case 1:
				enterNewProduct();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 2:
				checkProductID();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 3:
				showAllProducts();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 4:
				updateProductQuantity();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 5:
				deleteProduct();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 6:
				newOrder();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 7:
				checkOrderStatus();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 8:
				updateOrderStatus();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 9:
				deleteOrder();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 10:
				newCustomer();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 11:
				showCustomerContact();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 12:
				updateCustomerAddress();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 13:
				deleteCustomer();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 14:
				newCashier();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 15:
				cashierInfo();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
			case 16:
				removeCashier();
				TimeUnit.SECONDS.sleep(3);
				tableMenu();
				break;
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void choices(int choice) {
		switch (choice) {
		case 1:
			productMenu();
			choiceInput();
			break;
		case 2:
			orderMenu();
			choiceInput();
			break;
		case 3:
			customerMenu();
			choiceInput();
			break;
		case 4:
			cashierMenu();
			choiceInput();
			break;
		case 5:
			System.out.println("Closed");
			System.exit(0);
			break;
		}
	}
	
	public static void choiceInput() {
			System.out.println("Input your choice: ");
			Integer choice = scan.nextInt();
			if (choice == 0) {
				tableMenu();
			}else {
				choiceExecute(choice);
			}
				
	}

	//-------------For Product Menu------------------------/
	public static void enterNewProduct(){ // enter a new product
		System.out.println("Input product id: ");
		Integer id = scan.nextInt();
		scan.nextLine();
		System.out.println("Input product name: ");
		String name = scan.nextLine();
		System.out.println("Input product category: ");
		String category = scan.nextLine();
		System.out.println("Input product brand: ");
		String brand = scan.nextLine();
		System.out.println("Input product price: ");
		Integer price = scan.nextInt();
		scan.nextLine();
		System.out.println("Input product quantity: ");
		Integer quantity = scan.nextInt();
		try {
			control.newData(id,name,category,brand,price,quantity);
			} catch (Exception e) {
			e.printStackTrace();
			}
		
	}
	
	public static void checkProductID() {  // check a product if it exist in the database
		System.out.println("Enter product ID: ");
		Integer id = scan.nextInt();
		scan.nextLine();
		try {
			ResultSet rs = control.verifyID(id);
			if(rs.next()) {
				System.out.println("Product ID does exist in the database");
			}else {
				System.out.println("Product ID does not exist in the dabatase");
			}
			} catch (Exception e) {
			e.printStackTrace();
			}
	}
	
	public static void showProductInfo(Integer id) {
		try {
			ResultSet result = control.getProductInfo(id);
			ResultSetMetaData rsmd = result.getMetaData();
			int columnNumber = rsmd.getColumnCount();
			System.out.println();
			while (result.next()) {
				for (int i = 1; i <= columnNumber; i++) {
					if (i > 1) System.out.print(",   ");
					String columnValue = result.getString(i);
					System.out.print(columnValue + "  ");
				}
				System.out.println("");
			}
			} catch (Exception e) {
			e.printStackTrace();
			}
	}
	
	public static void showAllProducts() { //Shows all products
	try {
		ResultSet result = control.getAllProduct();
		ResultSetMetaData rsmd = result.getMetaData();
		int columnNumber = rsmd.getColumnCount();
		System.out.println();
		while (result.next()) {
			for (int i = 1; i <= columnNumber; i++) {
				if (i > 1) System.out.print(",   ");
				String columnValue = result.getString(i);
				System.out.print(columnValue + "  ");
			}
			System.out.println("");
		}
		} catch (Exception e) {
		e.printStackTrace();
		}
	}
	
	public static void updateProductQuantity() {
		System.out.println("Input the ID of the product: ");
		Integer ID = scan.nextInt();
		scan.nextLine();
		System.out.println("Input the new quantity for the product: ");
		Integer quantity = scan.nextInt();
		try {
			control.updateProductQty(ID,quantity);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void deleteProduct() { //Deletes a product
		System.out.println("Input the ID of the product that you want to delete: ");
		Integer ID = scan.nextInt();
		try{
			control.deleteProduct(ID);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	//----------------------------------------------------/
	
	//--------------------ORDER MENU----------------------/
	
	public static void newOrder() {
		System.out.println("Input order ID(must be unique): ");
		Integer ID = scan.nextInt();
		scan.nextLine();
		System.out.println("Input order quantity: ");
		Integer quantity = scan.nextInt();
		scan.nextLine();
		System.out.println("Input order type(Cash or Online): ");
		String type = scan.nextLine();
		System.out.println("Input the order status(Pending or Claimed): ");
		String status = scan.nextLine();
		System.out.println("Input the id of the customer who orderd: ");
		Integer cID = scan.nextInt();
		scan.nextLine();
		System.out.println("Input the id of the product: ");
		Integer pID = scan.nextInt();
		scan.nextLine();
		System.out.println("Input the id of the cashier: ");
		Integer caID = scan.nextInt();
		scan.nextLine();
		try {
			control.newOrder(ID,quantity,type,status,cID,pID,caID);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void checkOrderStatus() {
		System.out.println("Enter the id of the order you want to check: ");
		Integer id = scan.nextInt();
		try {
			ResultSet rs = control.checkOrderStatus(id);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnNumber = rsmd.getColumnCount();
			System.out.println();
			while (rs.next()) {
				for (int i = 1; i <= columnNumber; i ++) {
					if (i > 1) System.out.print(",   ");
					String columnValue = rs.getString(i);
					System.out.print("Current product status: ");
					System.out.print(columnValue + " ");
				}
				System.out.println("");
			}
			} catch (Exception e) {
			e.printStackTrace();
			}
	}
	
	public static void updateOrderStatus() {
		System.out.println("Enter product ID: ");
		Integer ID = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter new product status(Pending or Claimed): ");
		String status = scan.nextLine();
		try {
			control.updateOrderStatus(status,ID);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void deleteOrder() {
		System.out.println("Enter the ID of the order to be deleted: ");
		Integer id = scan.nextInt();
		try {
			control.deleteOrder(id);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//----------------------------------------------------/
	//--------------------CUSTOMER MENU-------------------/
	
	public static void newCustomer() {
		System.out.println("Enter new customer ID: ");
		Integer id = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter customer name: ");
		String name = scan.nextLine();
		System.out.println("Enter customer address: ");
		String address = scan.nextLine();
		System.out.println("Enter customer contact no: ");
		Integer contact = scan.nextInt();
		try {
			control.newCustomer(id,name,address,contact);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void showCustomerContact() {
		System.out.println("Input customer ID: ");
		Integer id = scan.nextInt();
		try {
			ResultSet rs = control.getCustomerContact(id);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnNumber = rsmd.getColumnCount();
			while(rs.next()) {
				for (int i = 1; i <= columnNumber; i++) {
				if(i > 1) System.out.print(",   ");
				String columnValue = rs.getString(i);
				System.out.print("Customer contact: ");
				System.out.print(columnValue + " ");
			}
			System.out.println("");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void updateCustomerAddress() {
		System.out.println("Input customer ID: ");
		Integer ID = scan.nextInt();
		scan.nextLine();
		System.out.println("Enter new address: ");
		String address = scan.nextLine();
		try {
			control.updateCustomerAddress(ID, address);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void deleteCustomer() {
		System.out.println("Input customer ID: ");
		Integer ID = scan.nextInt();
		scan.nextLine();
		try {
			control.deleteCustomer(ID);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	//----------------------------------------------------/
	//-------------------Cashier Menu---------------------/
	
	public static void newCashier() {
		System.out.println("Input a new cashier ID: ");
		Integer ID = scan.nextInt();
		scan.nextLine();
		System.out.println("Input cashier name: ");
		String name = scan.nextLine();
		try {
			control.newCashier(ID,name);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void cashierInfo() {
		System.out.println("Input cashier ID: ");
		Integer id = scan.nextInt();
		try {
			ResultSet result = control.getCashierInfo(id);
			ResultSetMetaData rsmd = result.getMetaData();
			int columnNumber = rsmd.getColumnCount();
			System.out.println();
			System.out.println("ID      Name          Salary");
			while (result.next()) {
				for (int i = 1; i <= columnNumber; i++) {
					if (i > 1) System.out.print(",   ");
					String columnValue = result.getString(i);
					System.out.print(columnValue + "  ");
				}
				System.out.println("");
			}
			} catch (Exception e) {
			e.printStackTrace();
			}
	}
	
	public static void removeCashier() {
		System.out.println("Input cashier ID: ");
		Integer id = scan.nextInt();
		try {
			control.deleteCashier(id);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//----------------------------------------------------/	
	
}
